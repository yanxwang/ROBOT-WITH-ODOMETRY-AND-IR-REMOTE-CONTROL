// Lab 9
// Che Kwanga

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz
// Stack:           4096 bytes (needed for sprintf)

// Hardware configuration:
// Frequency counter and timer input:
//   FREQ_IN on PC6 (WT1CCP0)
//   FREQ_IN on PC7 (WT1CCP1)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "clock.h"
#include "uart0.h"
#include "tm4c123gh6pm.h"

// PortC masks
#define FREQ_IN_MASK_1 64
#define FREQ_IN_MASK_2 128
// PortD masks
#define FREQ_IN_MASK 1 //WideTimer2
// Port E masks
#define SLEEP_MASK 16
// PortF masks
#define IN2_MASK 1
#define IN4_MASK 2
#define IN1_MASK 4
#define IN3_MASK 8

//Bit band Port E
#define SLEEP  (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 4*4)))

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
uint32_t frequency_PC6 = 0;
uint32_t frequency_PC7 = 0;

uint32_t time[50];
uint8_t count=0;
uint8_t code[32];
uint32_t t;
bool valid=false;
char codeWord[32];
char command[MAX_CHARS+1];
uint8_t bufferPosition=0;
//-----------------------------------------------------------------------------
// Data codes
//-----------------------------------------------------------------------------
//----------------------------------------------------------------------------
int address[16]={0,0,1,0,0,0,0,0,1,1,0,1,1,1,1,1};//address and complement, dataCodes in a 2D integer array, dataNames in a single char array
uint8_t dataCodes[50][16]={{0,0,0,1,0,0,0,0,1,1,1,0,1,1,1,1},{1,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1},{1,0,0,1,1,1,0,0,0,1,1,0,0,0,1,1},{0,1,0,1,1,1,1,0,1,0,1,0,0,0,0,1},{0,0,0,1,1,1,1,0,1,1,1,0,0,0,0,1},{1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1},{1,0,0,0,1,0,0,0,0,1,1,1,0,1,1,1},{0,1,0,0,1,0,0,0,1,0,1,1,0,1,1,1},{1,1,0,0,1,0,0,0,0,0,1,1,0,1,1,1},{0,0,1,0,1,0,0,0,1,1,0,1,0,1,1,1},{1,0,1,0,1,0,0,0,0,1,0,1,0,1,1,1},{0,1,1,0,1,0,0,0,1,0,0,1,0,1,1,1},{1,1,1,0,1,0,0,0,0,0,0,1,0,1,1,1},{0,0,0,1,1,0,0,0,1,1,1,0,0,1,1,1},{1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1},{0,0,1,1,0,0,1,0,1,1,0,0,1,1,0,1},{0,0,0,0,1,0,0,0,1,1,1,1,0,1,1,1},{0,1,0,1,1,0,0,0,1,0,1,0,0,1,1,1},{0,1,0,0,0,0,0,0,1,0,1,1,1,1,1,1},{1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1},{0,1,1,1,1,0,0,0,1,0,0,0,0,1,1,1},{0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0},{1,0,0,1,0,0,0,0,0,1,1,0,1,1,1,1},{0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1},{1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1},{0,1,1,0,1,0,1,0,1,0,0,1,0,1,0,1},{0,0,1,1,1,1,1,0,1,1,0,0,0,0,0,1},{0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,1},{1,1,0,0,0,0,1,0,0,0,1,1,1,1,0,1},{1,1,1,1,0,1,0,1,0,0,0,0,1,0,1,0},{0,0,0,0,0,0,1,0,1,1,1,1,1,1,0,1},{1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1},{0,0,1,0,0,0,1,0,1,1,0,1,1,1,0,1},{0,1,1,0,0,0,0,0,1,0,0,1,1,1,1,1},{1,0,0,0,0,0,1,0,0,1,1,1,1,1,0,1},{0,0,0,1,0,1,0,0,1,1,1,0,1,01,1},{1,1,0,1,1,0,1,0,0,0,1,0,0,1,0,1},{1,0,0,0,1,0,0,1,0,1,1,1,0,1,1,0},{0,1,1,1,0,0,0,0,1,0,0,0,1,1,1,1},{1,0,0,0,1,1,0,1,0,1,1,1,0,0,1,0},{1,1,1,1,0,0,0,1,0,0,0,0,1,1,1,0},{0,0,0,0,1,1,0,1,1,1,1,1,0,0,1,0},{0,1,0,1,1,1,0,1,1,0,1,0,0,0,1,0},{0,1,1,1,0,0,0,1,1,0,0,0,1,1,1,0},{0,1,0,0,1,1,1,0,1,0,1,1,0,0,0,1},{1,0,0,0,1,1,1,0,0,1,1,1,0,0,0,1},{1,1,0,0,0,1,1,0,0,0,1,1,1,0,0,1},{1,0,0,0,0,1,1,0,0,1,1,1,1,0,0,1}};
char* dataNames[50]={"Power","Source","Caption","Info","Search","TV","1","2","3","4","5","6","7","8","9","list","0","flashback","vol up","vol down","fav","Info","mute","ch up","ch down","netflix","home","amazon","settings","live zoom","up","left","ok","right","down","back","exit","sap","sleep","stop","rewind","play","pause","fast forward","red","green","yellow","blue"};

void initHw()
{
     // Initialize system clock to 40 MHz
     initSystemClockTo40Mhz();

     // Enable clocks
     SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;
     SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R1;
     SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R2 | SYSCTL_RCGCGPIO_R5 | SYSCTL_RCGCGPIO_R4;
     SYSCTL_RCGCPWM_R |= SYSCTL_RCGCPWM_R1;
     _delay_cycles(16);

     //unlock PF0
     GPIO_PORTF_LOCK_R = 0x4C4F434B;
     GPIO_PORTF_CR_R |= 1;

     // Configure LED and pushbutton pins
     GPIO_PORTF_DIR_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;
     GPIO_PORTF_AFSEL_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;
     GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF0_M | GPIO_PCTL_PF1_M | GPIO_PCTL_PF2_M | GPIO_PCTL_PF4_M);
     GPIO_PORTF_PCTL_R |= GPIO_PCTL_PF0_M1PWM4 | GPIO_PCTL_PF1_M1PWM5 | GPIO_PCTL_PF2_M1PWM6 | GPIO_PCTL_PF3_M1PWM7;
     GPIO_PORTF_DEN_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;

     //Configure Sleep pin
     GPIO_PORTE_DIR_R |= SLEEP_MASK;                  //set as output
     GPIO_PORTE_PUR_R |= SLEEP_MASK;                  //set logically high
     GPIO_PORTE_DEN_R |= SLEEP_MASK;                  //enable pin

     SYSCTL_SRPWM_R = SYSCTL_SRPWM_R1;                // reset PWM1 module
     SYSCTL_SRPWM_R = 0;                              // leave reset state
     PWM1_2_CTL_R = 0;                                // turn-off PWM1 generator 2 (drives outs 4 and 5)
     PWM1_3_CTL_R = 0;                                // turn-off PWM1 generator 3 (drives outs 6 and 7)

     PWM1_2_GENA_R = PWM_1_GENA_ACTCMPAD_ONE | PWM_1_GENA_ACTLOAD_ZERO;
                                                         // output 4 on PWM1, gen 2a, cmpa
     PWM1_2_GENB_R = PWM_1_GENB_ACTCMPBD_ONE | PWM_1_GENB_ACTLOAD_ZERO;
                                                         // output 5 on PWM1, gen 2b, cmpb
     PWM1_3_GENA_R = PWM_1_GENA_ACTCMPAD_ONE | PWM_1_GENA_ACTLOAD_ZERO;
                                                         // output 6 on PWM1, gen 3a, cmpa
     PWM1_3_GENB_R = PWM_1_GENB_ACTCMPBD_ONE | PWM_1_GENB_ACTLOAD_ZERO;
                                                         // output 7 on PWM1, gen 3b, cmpb

     PWM1_2_LOAD_R = 1024;                                // set frequency to 40 MHz sys clock / 2 / 1024 = 19.53125 kHz
     PWM1_3_LOAD_R = 1024;
                                                          // invert outputs so duty cycle increases with increasing compare values
     PWM1_2_CMPA_R = 0;
     PWM1_2_CMPB_R = 0;
     PWM1_3_CMPB_R = 0;
     PWM1_3_CMPA_R = 0;

     PWM1_2_CTL_R = PWM_0_CTL_ENABLE;                     // turn-on PWM1 generator 2
     PWM1_3_CTL_R = PWM_0_CTL_ENABLE;                     // turn-on PWM1 generator 3
     PWM1_ENABLE_R = PWM_ENABLE_PWM4EN | PWM_ENABLE_PWM5EN | PWM_ENABLE_PWM6EN | PWM_ENABLE_PWM7EN;
                                                         //enable outputs

    // Configure FREQ_IN for frequency counter
     GPIO_PORTC_DIR_R &= ~(FREQ_IN_MASK_1 | FREQ_IN_MASK_2);
	 GPIO_PORTC_AFSEL_R |= FREQ_IN_MASK_1 | FREQ_IN_MASK_2;  // select alternative functions for FREQ_IN pin
     GPIO_PORTC_PCTL_R &= ~GPIO_PCTL_PC6_M;                  // map alt fns to FREQ_IN
     GPIO_PORTC_PCTL_R &= ~GPIO_PCTL_PC7_M;
     GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC6_WT1CCP0;
     GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC7_WT1CCP1;
     GPIO_PORTC_PUR_R |=  FREQ_IN_MASK_1 | FREQ_IN_MASK_2;
     GPIO_PORTC_DEN_R |=  FREQ_IN_MASK_1 | FREQ_IN_MASK_2;   // enable bit 6 for digital input

    // Configure Wide Timer 1 as counter
     WTIMER1_CTL_R &= ~TIMER_CTL_TAEN;                // turn-off counter before reconfiguring
     WTIMER1_CFG_R = 4;                               // configure as 32-bit counter (A only)
     WTIMER1_TAMR_R = TIMER_TAMR_TAMR_CAP | TIMER_TAMR_TACDIR; // configure for edge count mode, count up
     WTIMER1_CTL_R = 0;                               //
     WTIMER1_IMR_R = 0;                               // turn-off interrupts
     WTIMER1_TAV_R = 0;                               // zero counter for first period
     WTIMER1_CTL_R |= TIMER_CTL_TAEN;                 // turn-on counter
     NVIC_EN3_R &= ~(1 << (INT_WTIMER1A-16-96));      // turn-off interrupt 112 (WTIMER1A)
}

void initIR()
{
    // Initialize system clock to 40 MHz
       initSystemClockTo40Mhz();

       // Enable clocks
       SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R2;
       SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R3;
       _delay_cycles(3);

       // Configure FREQ_IN for frequency counter
       GPIO_PORTD_DIR_R &=~FREQ_IN_MASK;                      // define as input
       GPIO_PORTD_AFSEL_R |= FREQ_IN_MASK;              // select alternative functions for FREQ_IN pin
       GPIO_PORTD_PCTL_R &= ~GPIO_PCTL_PD0_M;           // map alt fns to FREQ_IN
       GPIO_PORTD_PCTL_R |= GPIO_PCTL_PD0_WT2CCP0;
       GPIO_PORTD_DEN_R |= FREQ_IN_MASK;                // enable bit 6 for digital input

       GPIO_PORTD_IS_R &=~FREQ_IN_MASK;    //setting 0 makes it edge sensitive, 1 makes it level sensitive
       GPIO_PORTD_IBE_R &=~FREQ_IN_MASK;   //setting 0 makes interrupts controlled by Interrupt event register for a single edge or level
       GPIO_PORTD_IEV_R &=~FREQ_IN_MASK;   //setting 0 makes it detect falling edges
       GPIO_PORTD_ICR_R |=FREQ_IN_MASK;    //clear any interrupts
       GPIO_PORTD_IM_R  |=FREQ_IN_MASK;    //interrupt is sent to interrupt controller
       NVIC_EN0_R |= 1 << (INT_GPIOD-16);  // set interrupt

       // Configure Wide Timer 1 as timer
           WTIMER2_CTL_R &= ~TIMER_CTL_TAEN;                // turn-off counter before reconfiguring
           WTIMER2_CFG_R   = 4;                               // configure as 32-bit counter (A only)
           WTIMER2_TAMR_R  = TIMER_TAMR_TAMR_PERIOD;          // make the counter periodic
           WTIMER2_TAMR_R &= ~TIMER_TAMR_TACDIR;             // make it count down
           WTIMER2_TAV_R  = 0xFFFFFFFF;                      // MAX counter for first period
           WTIMER2_TAPR_R  = 40;                              // pre-scale value to get 1MHZ rate
           WTIMER2_CTL_R |= TIMER_CTL_TAEN;                 // turn-on counter
}
void combineCommand(char* str){
    uint8_t i=0;
    while(str[i]!='\0'){
        command[bufferPosition]=str[i];
        i++;
        bufferPosition++;
    }
    command[bufferPosition]=',';
    bufferPosition++;
    if(str[0]=='o'){
        if(str[1]=='k'){
            bufferPosition=0;
            valid=true;
        }else{
            valid=false;
        }
    }else{
        valid=false;
    }

}
// Print the code after verifying that the code is valid and complementary.
void printCode(){
    //check for appropriate address and complementary. Stop if not valid.
    uint8_t i,j,k;
    for(i=0;i<16;i++){
          if(codeWord[i]==address[i]){
             if(i==15){
             }
          }else{
             return;
              }
        }
    //check dataCodes for matching code and print corresponding name from dataNames
    for(j=0;j<48;j++){
        for(i=0;i<16;i++){
            k=16+i;
         if(codeWord[k]==dataCodes[j][i]){
           if(i==15){
            putsUart0("\t");
            putsUart0(dataNames[j]);
            if(bufferPosition<=MAX_CHARS){
                combineCommand(dataNames[j]);
            }else{
                bufferPosition=0;
            }
            return;
              }
           }else{break;}
          }
    }
}
void GPIOIsr(){
        time[count]=WTIMER2_TAV_R;      //place time stamp from timer
        if(count==0){
            count++;
            GPIO_PORTD_ICR_R |=FREQ_IN_MASK; //clear interrupt flag
            return;
        }
        if(count==1){
            uint32_t t=time[0]-time[1];   //get time interval between edges
            t=t/1000;                     //to get a more appropriate value
             if(((t<=14)&&(t>=13))){      //detect leader code
              count++;
              GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
              return;
             }else{
                count=0;
                GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
                return;
               }
            }
        if(count==34){
           int k;
           WTIMER2_TAV_R = 0xFFFFFFFF;  //reset timer
           for(k=0;k<count-2;k++){
           codeWord[k]=code[k];         //place code into a char for external use
            }
           printCode();                 //call print method to print appropriate code
           count=0;
            }
        if(count>34){count=0;           //reset the count in case any count exceeds required edges
        GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
            return;}
        if(count>1){
             uint32_t t=time[count-1]-time[count];
             t=t/1000;
             if((t<2)&&(t>=1)){        //detect 0 bit
                 code[count-2]=0;
                 count++;
                 GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
                 return;
             }
             if((t<3)&&(t>=2)){      //detect 1 bit
                 code[count-2]=1;    //place corresponding bit into code, two places down to start from zero
                 count++;
                 GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
                 return;
                }else{
                  count=0;
                 }
             count++;
             GPIO_PORTD_ICR_R |=FREQ_IN_MASK;
             return;
             }
   }
 char* getCode(){
     return command;
 }

 bool sameString(char* str, char* stm){
     uint8_t i=0;
     while(str[i]==stm[i]){
         i++;
         if(str[i]=='\0'){
             return 1;
         }
     }
     return 0;

 }
// Frequency counter service publishing latest frequency measurements every second
void timer1Isr()
{
    frequency_PC6 = WTIMER1_TAV_R;                   // read counter input
    WTIMER1_TAV_R = 0;                               // reset counter for next period
	TIMER1_ICR_R = TIMER_ICR_TATOCINT;               // clear interrupt flag
}

//ratio is 1:46
void forward(uint16_t dist_cm){
    //1 rotation=19.95cm
    //1 rotation is 46 small rotations.
    float distancePerRotation = 19.95;
    float distanceInRotations = (dist_cm/distancePerRotation)*46;
    float rotationsCovered=0;
    WTIMER1_TAV_R=0;
    PWM1_3_CMPA_R = 800; // left forward
    PWM1_2_CMPB_R = 1023; // right forward
    while(distanceInRotations>rotationsCovered){
        rotationsCovered=WTIMER1_TAV_R;
    }
    PWM1_3_CMPA_R = 0; // left forward
    PWM1_2_CMPB_R = 0; // right forward
    WTIMER1_TAV_R=0;
}
void reverse(uint16_t dist_cm){
    float distancePerRotation = 19.95;
    float distanceInRotations = (dist_cm/distancePerRotation)*46;
    float rotationsCovered=0;
    WTIMER1_TAV_R=0;
    PWM1_2_CMPA_R = 800; // left reverse
    PWM1_3_CMPB_R = 850; // right reverse
    while(distanceInRotations>rotationsCovered){
        rotationsCovered=WTIMER1_TAV_R;
    }
    PWM1_2_CMPA_R = 0; // left reverse
    PWM1_3_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void cw(uint16_t degrees){
    float fullCircle=360;
    float distancePerRotation = 19.95;
    float distancePerCircleRotation = 378;
    float rotationsCovered=0;
    float degreesInCircleDistance = (degrees/fullCircle)*distancePerCircleRotation;
    float distanceInRotations = (degreesInCircleDistance/distancePerRotation)*46;
    WTIMER1_TAV_R=0;
    PWM1_3_CMPA_R = 1023; // left forward
    PWM1_3_CMPB_R = 1023; // right reverse
    while(distanceInRotations>rotationsCovered){
            rotationsCovered=WTIMER1_TAV_R;
        }
    PWM1_3_CMPA_R = 0; // left forward
    PWM1_3_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void ccw(uint16_t degrees){
    float fullCircle=360;
    float distancePerRotation = 19.95;
    float distancePerCircleRotation = 378;
    float rotationsCovered=0;
    float degreesInCircleDistance = (degrees/fullCircle)*distancePerCircleRotation;
    float distanceInRotations = (degreesInCircleDistance/distancePerRotation)*46;
    WTIMER1_TAV_R=0;
    PWM1_2_CMPA_R = 1023; // left reverse
    PWM1_2_CMPB_R = 1023; // right forward
    while(distanceInRotations>rotationsCovered){
               rotationsCovered=WTIMER1_TAV_R;
           }
    PWM1_2_CMPA_R = 0; // left forward
    PWM1_2_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void start(){
    SLEEP=1;           //make sleep pin high power on DRV 8833
}
void stop(){
    SLEEP=0;           //make sleep pin low to save power on DRV 8833
}

//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

int main(void)
{
    USER_DATA data;
    // Initialize hardware
    initHw();
    initUart0();
    initIR();
    start();
    char* stopCheck="stop";
    while (true)
    {
    // handle UART commands
       if(kbhitUart0()){
         getsUart0(&data);
         putsUart0(data.buffer);
         parseFields(&data);
         char* forwardCheck="forward";
         char* reverseCheck="reverse";
         char* cwCheck="cw";
         char* ccwCheck="ccw";
         char* str=(&data.buffer[data.fieldPosition[0]]);
         if(sameString(str,forwardCheck)){
                            uint16_t distance=(uint16_t) getFieldInteger(&data,1);
                            forward(distance);
                }
         if(sameString(str,reverseCheck)){
                                     uint16_t distance=(uint16_t) getFieldInteger(&data,1);
                                     reverse(distance);
                         }
         if(sameString(str,cwCheck)){
                                     uint16_t distance=(uint16_t) getFieldInteger(&data,1);
                                     cw(distance);
                         }
         if(sameString(str,ccwCheck)){
                                     uint16_t distance=(uint16_t) getFieldInteger(&data,1);
                                     ccw(distance);
                         }
         if(sameString(str,stopCheck)){
                      stop();
                  }
       }

     if(valid==true){
          valid=false;
        char* word=getCode();
        uint8_t i=0;
        while(word[i]!='\0'){
          data.buffer[i]=word[i];
          i++;
          if(word[i]=='k'){
              data.buffer[i]=word[i];
              i++;
              data.buffer[i]='\0';
              break;
          }
        }
        putsUart0(data.buffer);
        parseFields(&data);
        char* upCheck="up";
        char* downCheck="down";
        char* rightCheck="right";
        char* leftCheck="left";
        char* str=(&data.buffer[data.fieldPosition[0]]);
        if(sameString(str,upCheck)){
              uint16_t distance=(uint16_t) getFieldInteger(&data,1);
              distance=distance*10;
              distance=distance + (uint16_t) getFieldInteger(&data,2);
              distance=distance*10;
              distance=distance + (uint16_t) getFieldInteger(&data,3);
              forward(distance);
          }
        if(sameString(str,downCheck)){
            uint16_t distance=(uint16_t) getFieldInteger(&data,1);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,2);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,3);
            reverse(distance);
          }
        if(sameString(str,rightCheck)){
            uint16_t distance=(uint16_t) getFieldInteger(&data,1);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,2);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,3);
            cw(distance);
          }
        if(sameString(str,leftCheck)){
            uint16_t distance=(uint16_t) getFieldInteger(&data,1);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,2);
            distance=distance*10;
            distance=distance + (uint16_t)getFieldInteger(&data,3);
            ccw(distance); //enter 090
          }
        if(sameString(str,stopCheck)){
              stop();
          }
       }
    }
}
