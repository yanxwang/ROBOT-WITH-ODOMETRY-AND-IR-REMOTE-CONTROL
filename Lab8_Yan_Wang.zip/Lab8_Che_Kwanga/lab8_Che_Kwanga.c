// Lab 8
// Che Kwanga

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz
// Stack:           4096 bytes (needed for sprintf)

// Hardware configuration:
// Frequency counter and timer input:
//   FREQ_IN on PC6 (WT1CCP0)
//   FREQ_IN on PC7 (WT1CCP1)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "tm4c123gh6pm.h"

// PortC masks
#define FREQ_IN_MASK_1 64
#define FREQ_IN_MASK_2 128

// PortF masks
#define IN2_MASK 1
#define IN4_MASK 2
#define IN1_MASK 4
#define IN3_MASK 8

// PortE masks
#define IR_MASK 1
#define SLEEP_MASK 16
//Bit band Port E
#define SLEEP  (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 4*4)))

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
uint32_t frequency_PC6 = 0;
uint32_t frequency_PC7 = 0;

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initHw()
{
     // Initialize system clock to 40 MHz
     initSystemClockTo40Mhz();

     // Enable clocks
     SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;
     SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R1;
     SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R2 | SYSCTL_RCGCGPIO_R5 | SYSCTL_RCGCGPIO_R4;
     SYSCTL_RCGCPWM_R |= SYSCTL_RCGCPWM_R1;
     _delay_cycles(16);

     //unlock PF0
     GPIO_PORTF_LOCK_R = 0x4C4F434B;
     GPIO_PORTF_CR_R |= 1;

     // Configure LED and pushbutton pins
     GPIO_PORTF_DIR_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;
     GPIO_PORTF_AFSEL_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;
     GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF0_M | GPIO_PCTL_PF1_M | GPIO_PCTL_PF2_M | GPIO_PCTL_PF4_M);
     GPIO_PORTF_PCTL_R |= GPIO_PCTL_PF0_M1PWM4 | GPIO_PCTL_PF1_M1PWM5 | GPIO_PCTL_PF2_M1PWM6 | GPIO_PCTL_PF3_M1PWM7;
     GPIO_PORTF_DEN_R |= IN1_MASK | IN2_MASK | IN3_MASK | IN4_MASK;

     //Configure Sleep pin
     GPIO_PORTE_DIR_R |= SLEEP_MASK;                  //set as output
     GPIO_PORTE_PUR_R |= SLEEP_MASK;                  //set logically high
     GPIO_PORTE_DEN_R |= SLEEP_MASK;                  //enable pin

     SYSCTL_SRPWM_R = SYSCTL_SRPWM_R1;                // reset PWM1 module
     SYSCTL_SRPWM_R = 0;                              // leave reset state
     PWM1_2_CTL_R = 0;                                // turn-off PWM1 generator 2 (drives outs 4 and 5)
     PWM1_3_CTL_R = 0;                                // turn-off PWM1 generator 3 (drives outs 6 and 7)

     PWM1_2_GENA_R = PWM_1_GENA_ACTCMPAD_ONE | PWM_1_GENA_ACTLOAD_ZERO;
                                                         // output 4 on PWM1, gen 2a, cmpa
     PWM1_2_GENB_R = PWM_1_GENB_ACTCMPBD_ONE | PWM_1_GENB_ACTLOAD_ZERO;
                                                         // output 5 on PWM1, gen 2b, cmpb
     PWM1_3_GENA_R = PWM_1_GENA_ACTCMPAD_ONE | PWM_1_GENA_ACTLOAD_ZERO;
                                                         // output 6 on PWM1, gen 3a, cmpa
     PWM1_3_GENB_R = PWM_1_GENB_ACTCMPBD_ONE | PWM_1_GENB_ACTLOAD_ZERO;
                                                         // output 7 on PWM1, gen 3b, cmpb

     PWM1_2_LOAD_R = 1024;                                // set frequency to 40 MHz sys clock / 2 / 1024 = 19.53125 kHz
     PWM1_3_LOAD_R = 1024;
                                                          // invert outputs so duty cycle increases with increasing compare values
     PWM1_2_CMPA_R = 0;
     PWM1_2_CMPB_R = 0;
     PWM1_3_CMPB_R = 0;
     PWM1_3_CMPA_R = 0;

     PWM1_2_CTL_R = PWM_0_CTL_ENABLE;                     // turn-on PWM1 generator 2
     PWM1_3_CTL_R = PWM_0_CTL_ENABLE;                     // turn-on PWM1 generator 3
     PWM1_ENABLE_R = PWM_ENABLE_PWM4EN | PWM_ENABLE_PWM5EN | PWM_ENABLE_PWM6EN | PWM_ENABLE_PWM7EN;
                                                         //enable outputs

    // Configure FREQ_IN for frequency counter
     GPIO_PORTC_DIR_R &= ~(FREQ_IN_MASK_1 | FREQ_IN_MASK_2);
     GPIO_PORTC_AFSEL_R |= FREQ_IN_MASK_1 | FREQ_IN_MASK_2;  // select alternative functions for FREQ_IN pin
     GPIO_PORTC_PCTL_R &= ~GPIO_PCTL_PC6_M;                  // map alt fns to FREQ_IN
     GPIO_PORTC_PCTL_R &= ~GPIO_PCTL_PC7_M;
     GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC6_WT1CCP0;
     GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC7_WT1CCP1;
     GPIO_PORTC_PUR_R |=  FREQ_IN_MASK_1 | FREQ_IN_MASK_2;
     GPIO_PORTC_DEN_R |=  FREQ_IN_MASK_1 | FREQ_IN_MASK_2;   // enable bit 6 for digital input

    // Configure Wide Timer 1 as counter
     WTIMER1_CTL_R &= ~TIMER_CTL_TAEN;                // turn-off counter before reconfiguring
     WTIMER1_CFG_R = 4;                               // configure as 32-bit counter (A only)
     WTIMER1_TAMR_R = TIMER_TAMR_TAMR_CAP | TIMER_TAMR_TACDIR; // configure for edge count mode, count up
     WTIMER1_CTL_R = 0;                               //
     WTIMER1_IMR_R = 0;                               // turn-off interrupts
     WTIMER1_TAV_R = 0;                               // zero counter for first period
     WTIMER1_CTL_R |= TIMER_CTL_TAEN;                 // turn-on counter
     NVIC_EN3_R &= ~(1 << (INT_WTIMER1A-16-96));      // turn-off interrupt 112 (WTIMER1A)
}

// Frequency counter service publishing latest frequency measurements every second
void timer1Isr()
{
    frequency_PC6 = WTIMER1_TAV_R;                   // read counter input
    WTIMER1_TAV_R = 0;                               // reset counter for next period
    TIMER1_ICR_R = TIMER_ICR_TATOCINT;               // clear interrupt flag
}
//ratio is 1:46
void forward(uint16_t dist_cm){
    //1 rotation=19.95cm
    //1 rotation is 46 small rotations.
    float distancePerRotation = 19.95;
    float distanceInRotations = (dist_cm/distancePerRotation)*46;
    float rotationsCovered=0;
    WTIMER1_TAV_R=0;
    PWM1_3_CMPA_R = 800; // left forward
    PWM1_2_CMPB_R = 1023; // right forward
    while(distanceInRotations>rotationsCovered){
        rotationsCovered=WTIMER1_TAV_R;
    }
    PWM1_3_CMPA_R = 0; // left forward
    PWM1_2_CMPB_R = 0; // right forward
    WTIMER1_TAV_R=0;
}
void reverse(uint16_t dist_cm){
    float distancePerRotation = 19.95;
    float distanceInRotations = (dist_cm/distancePerRotation)*46;
    float rotationsCovered=0;
    WTIMER1_TAV_R=0;
    PWM1_2_CMPA_R = 800; // left reverse
    PWM1_3_CMPB_R = 850; // right reverse
    while(distanceInRotations>rotationsCovered){
        rotationsCovered=WTIMER1_TAV_R;
    }
    PWM1_2_CMPA_R = 0; // left reverse
    PWM1_3_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void cw(uint16_t degrees){
    float fullCircle=360;
    float distancePerRotation = 19.95;
    float distancePerCircleRotation = 378;
    float rotationsCovered=0;
    float degreesInCircleDistance = (degrees/fullCircle)*distancePerCircleRotation;
    float distanceInRotations = (degreesInCircleDistance/distancePerRotation)*46;
    WTIMER1_TAV_R=0;
    PWM1_3_CMPA_R = 1023; // left forward
    PWM1_3_CMPB_R = 1023; // right reverse
    while(distanceInRotations>rotationsCovered){
            rotationsCovered=WTIMER1_TAV_R;
        }
    PWM1_3_CMPA_R = 0; // left forward
    PWM1_3_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void ccw(uint16_t degrees){
    float fullCircle=360;
    float distancePerRotation = 19.95;
    float distancePerCircleRotation = 378;
    float rotationsCovered=0;
    float degreesInCircleDistance = (degrees/fullCircle)*distancePerCircleRotation;
    float distanceInRotations = (degreesInCircleDistance/distancePerRotation)*46;
    WTIMER1_TAV_R=0;
    PWM1_2_CMPA_R = 1023; // left reverse
    PWM1_2_CMPB_R = 1023; // right forward
    while(distanceInRotations>rotationsCovered){
               rotationsCovered=WTIMER1_TAV_R;
           }
    PWM1_2_CMPA_R = 0; // left forward
    PWM1_2_CMPB_R = 0; // right reverse
    WTIMER1_TAV_R=0;
}
void start(){
    SLEEP=1;           //make sleep pin high power on DRV 8833
}
void stop(){
    SLEEP=0;           //make sleep pin low to save power on DRV 8833
}
//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

int main(void)
{
    // Initialize hardware
    initHw();
    while (true)
    {}
}
//sleep-PE4
//IR input PE0
// so it gives speed of the motors. Convert rotations to distance.
